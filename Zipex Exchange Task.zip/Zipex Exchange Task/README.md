# StockExchange
Stock exchange order book on server side which can be used in Stock Exchange implementation. 
Smart Contracts for using order books for Ethereum token exchanging.
The client is GUI for stock exchange.

## Install
Install backend depencies. Be sure that you have installed Node.js.

```
cd server
npm install
```

Install frontend depencies.

```
cd ..
cd client
npm install
```

## Usage


