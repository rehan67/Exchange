
import {Orders} from './orders';
export default  () => {
    return new Orders();
}