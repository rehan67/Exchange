export class Balances
{
    constructor() 
    {

    }

    getBalance(id)
    {
        
    }
}