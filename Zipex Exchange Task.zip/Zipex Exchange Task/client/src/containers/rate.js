import React from 'react';
export default  ( {rate} ) => {
    return (
        <div>
         <div> 
            {rate}
         </div>
        </div>
    )
}